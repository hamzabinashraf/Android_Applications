package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText edit_weight, edit_heightFT, edit_heightIn;
        Button btnCalculator;
        TextView textResult;
        LinearLayout llMain;

        edit_weight = findViewById(R.id.edit_weight);
        edit_heightFT = findViewById(R.id.edit_heightFT);
        edit_heightIn = findViewById(R.id.edit_heightIn);
        btnCalculator = findViewById(R.id.btnCalculator);
        textResult = findViewById(R.id.textResult);
        llMain = findViewById(R.id.llMain);

        btnCalculator.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                int wt = Integer.parseInt(edit_weight.getText().toString());
                int ft = Integer.parseInt(edit_heightFT.getText().toString());
                int In = Integer.parseInt(edit_heightIn.getText().toString());

                int totalIn = ft*12 + In;

                double totalCm = totalIn*2.53;

                double totalM = totalCm/100;

                double bmi = wt/(totalM*totalM);

                if (bmi>25){
                    textResult.setText("You are Over_Weight!");
                    llMain.setBackgroundColor(getResources().getColor(R.color.colorOW));
                }
                else if (bmi<18){
                    textResult.setText("You are Under_Weight!");
                    llMain.setBackgroundColor(getResources().getColor(R.color.colorUW));
                }
                else {
                    textResult.setText("You are Healthy!");
                    llMain.setBackgroundColor(getResources().getColor(R.color.colorH));
                }
            }
        });

    }
}